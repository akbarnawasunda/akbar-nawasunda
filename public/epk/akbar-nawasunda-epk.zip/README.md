# Akbar Nawasunda — press kit

Produser, remixer, dan DJ asal Bandung Barat, Indonesia. Breakbeat, Indo Bass, Jedag Jedug,
Jungle Dutch. Aktif sejak 2020. Alias: DJ Akbar Remix.

## Isi paket
- press-photo-print.jpg   potret resmi, 1200 px, untuk cetak
- press-photo-web.webp    potret resmi, 960 px, untuk web
- an-mark-transparent.png monogram AN, latar transparan
- lockup-transparent.png  lockup AN + wordmark, latar transparan

## Fakta terverifikasi
- Nama panggung: Akbar Nawasunda
- Nama legal: Idel Akbar Ramadan
- Alias: DJ Akbar Remix
- Basis: Bandung Barat, Indonesia
- Aktif sejak: 2020
- Genre: Breakbeat, Indo Bass
- Situs: https://akbarnawasunda.my.id
- Spotify: https://open.spotify.com/intl-id/artist/7KOQuIQLuxyklLox0RDMMw
- YouTube: https://www.youtube.com/@akbarnawasunda
- SoundCloud: https://soundcloud.com/akbarnawasunda
- TikTok: https://www.tiktok.com/@akbarnawasunda

## Catatan
Bio panjang, kontak booking, dan daftar rilis lengkap menyusul. Mohon jangan menambahkan
angka pendengar, penghargaan, atau tautan platform di luar daftar di atas.

© Akbar Nawasunda. Foto dan logo boleh dipakai untuk pemberitaan dan promosi yang menyebut
Akbar Nawasunda.
